module traceabs_checker;
      integer ant_hits = 0;
      integer fail_hits = 0;
      reg ant_d = 1'b0;

      // property assertion disabled after compiler probe

      always @(posedge tb_case119.clk) begin
        if (!tb_case119.rst_n) begin
  ant_d <= 1'b0;
end else begin
  if ((tb_case119.enable_i && tb_case119.accept_boundary_dbg) |=> ($stable(tb_case119.filter_i)) ant_hits = ant_hits + 1;
  if ((tb_case119.enable_i && tb_case119.accept_boundary_dbg) |=> ($stable(tb_case119.filter_i) && !((tb_case119.filter_o == $past(tb_case119.filter_i))))) fail_hits = fail_hits + 1;
  ant_d <= (tb_case119.enable_i && tb_case119.accept_boundary_dbg) |=> ($stable(tb_case119.filter_i);
end
      end

      final begin
        $display("TRACEABS_METRIC ant_hits=%0d fail_hits=%0d", ant_hits, fail_hits);
      end
    endmodule
