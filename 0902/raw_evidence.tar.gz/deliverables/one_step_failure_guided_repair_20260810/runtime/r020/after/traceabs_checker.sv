module traceabs_checker;
      integer ant_hits = 0;
      integer fail_hits = 0;
      reg ant_d = 1'b0;

      // property assertion disabled after compiler probe

      always @(posedge tb_case113.clk) begin
        if (!tb_case113.rst_n) begin
  ant_d <= 1'b0;
end else begin
  if ((1'b1)) ant_hits = ant_hits + 1;
  if ((1'b1) && !((tb_case113.q_posedge_pulse_o) == (tb_case113.q_sync_o & ~$past(tb_case113.q_sync_o)))) fail_hits = fail_hits + 1;
  ant_d <= (1'b1);
end
      end

      final begin
        $display("TRACEABS_METRIC ant_hits=%0d fail_hits=%0d", ant_hits, fail_hits);
      end
    endmodule
